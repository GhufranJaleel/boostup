/*
 *
 * Products constants
 *
 */

export const DEFAULT_ACTION = 'src/Products/DEFAULT_ACTION';
