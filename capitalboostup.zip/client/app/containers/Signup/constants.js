/*
 *
 * Signup constants
 *
 */

export const SIGNUP_CHANGE = 'src/Signup/SIGNUP_CHANGE';
export const SIGNUP_RESET = 'src/Signup/SIGNUP_RESET';
export const SET_SIGNUP_LOADING = 'src/Signup/SET_SIGNUP_LOADING';
export const SET_SIGNUP_SUBMITTING = 'src/Signup/SET_SIGNUP_SUBMITTING';
export const SET_SIGNUP_FORM_ERRORS = 'src/Signup/SET_SIGNUP_FORM_ERRORS';
export const SUBSCRIBE_CHANGE = 'src/Signup/SUBSCRIBE_CHANGE';
